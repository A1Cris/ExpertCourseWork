﻿using Domain.Entities;

namespace Domain.Abstraction;

public interface IRuleRepository : IGenericRepository<RuleEntity>
{

}