﻿using Domain.Entities;

namespace Domain.Abstraction;

public interface IClauseRepository : IGenericRepository<ClauseEntity>
{
}