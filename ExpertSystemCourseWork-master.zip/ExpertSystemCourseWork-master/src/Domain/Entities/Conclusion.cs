﻿namespace Domain.Entities;

public class Conclusion : ClauseEntity
{

}