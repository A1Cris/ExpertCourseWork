﻿namespace Domain.Entities;

public class Antecedent : ClauseEntity
{
    public int RuleId { get; set; }
}