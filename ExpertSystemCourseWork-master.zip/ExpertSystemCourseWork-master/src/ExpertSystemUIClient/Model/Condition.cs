﻿namespace ExpertSystemUI.Model;

public enum Condition
{
    None=-1,
    Equal=0,
    Greater=1,
    Less=2,
}