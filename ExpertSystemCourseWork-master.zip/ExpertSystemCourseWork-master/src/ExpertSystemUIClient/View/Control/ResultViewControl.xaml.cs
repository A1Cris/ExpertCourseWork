﻿using System.Windows.Controls;

namespace ExpertSystemUI.View.Control;

public partial class ResultViewControl : UserControl
{
    public ResultViewControl()
    {
        InitializeComponent();
    }
}