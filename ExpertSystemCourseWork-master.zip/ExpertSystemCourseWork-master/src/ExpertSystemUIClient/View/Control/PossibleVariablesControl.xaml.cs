﻿using System.Windows.Controls;

namespace ExpertSystemUI.View.Control;

public partial class PossibleVariablesControl : UserControl
{
    public PossibleVariablesControl()
    {
        InitializeComponent();
    }
}