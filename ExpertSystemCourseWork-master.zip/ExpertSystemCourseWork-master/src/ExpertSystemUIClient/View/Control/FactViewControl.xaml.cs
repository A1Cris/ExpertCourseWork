﻿using System.Windows.Controls;

namespace ExpertSystemUI.View.Control;

public partial class FactViewControl : UserControl
{
    public FactViewControl()
    {
        InitializeComponent();
    }
}