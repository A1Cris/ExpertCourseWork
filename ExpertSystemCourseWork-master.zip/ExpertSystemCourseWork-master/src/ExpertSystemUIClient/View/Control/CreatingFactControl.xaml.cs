﻿using System.Windows.Controls;

namespace ExpertSystemUI.View.Control;

public partial class CreatingFactControl : UserControl
{
    public CreatingFactControl()
    {
        InitializeComponent();
    }
}