﻿using System.Windows.Controls;

namespace ExpertSystemUI.View.Control;

public partial class FactsViewControl : UserControl
{
    public FactsViewControl()
    {
        InitializeComponent();
    }
}