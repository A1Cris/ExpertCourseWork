﻿using System.Windows;

namespace ExpertSystemUI;

/// <summary>
///     Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{
}