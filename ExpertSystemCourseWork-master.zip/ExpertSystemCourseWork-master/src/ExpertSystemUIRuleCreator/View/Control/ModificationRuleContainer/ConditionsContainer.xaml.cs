﻿using System.Windows.Controls;

namespace ExpertSystemUIRuleCreator.View.Control.ModificationRuleContainer;

public partial class ConditionsContainer : UserControl
{
    public ConditionsContainer()
    {
        InitializeComponent();
    }
}