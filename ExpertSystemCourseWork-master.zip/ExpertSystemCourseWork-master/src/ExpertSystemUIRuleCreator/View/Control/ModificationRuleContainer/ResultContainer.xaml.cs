﻿using System.Windows.Controls;

namespace ExpertSystemUIRuleCreator.View.Control.ModificationRuleContainer;

public partial class ResultContainer : UserControl
{
    public ResultContainer()
    {
        InitializeComponent();
    }
}