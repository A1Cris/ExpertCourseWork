﻿using System.Windows.Controls;

namespace ExpertSystemUIRuleCreator.View.Control;

public partial class EditingRuleDialog : UserControl
{
    public EditingRuleDialog()
    {
        InitializeComponent();
    }
}