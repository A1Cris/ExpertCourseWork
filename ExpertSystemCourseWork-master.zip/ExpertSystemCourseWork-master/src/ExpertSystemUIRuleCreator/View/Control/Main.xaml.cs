﻿using System.Windows.Controls;

namespace ExpertSystemUIRuleCreator.View.Control;

public partial class Main : UserControl
{
    public Main()
    {
        InitializeComponent();
    }
}