﻿using System.Windows.Controls;

namespace ExpertSystemUIRuleCreator.View.Control;

public partial class RulesControl : UserControl
{
    public RulesControl()
    {
        InitializeComponent();
    }
}