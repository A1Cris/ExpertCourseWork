﻿using System.Windows.Controls;

namespace ExpertSystemUIRuleCreator.View.Control;

public partial class CreatingRuleControl : UserControl
{
    public CreatingRuleControl()
    {
        InitializeComponent();
    }
}