﻿namespace ExpertSystemUIRuleCreator.Model;

public interface IClearable
{
    void Clear();
}